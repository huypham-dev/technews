<?php $__env->startSection('content'); ?>
<!-- Posts -->
<?php
?>
<?php if(!isset($key)): ?>
<h4 class="cat-title mb25"><?php echo e($cate); ?></h4>
<?php $__env->startSection('title'); ?>
| <?php echo e($cate); ?>

<?php $__env->stopSection(); ?>
<section class="row">
	<!-- Category posts -->
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<article class="post six column">
		<?php if($post->post_type=='video'): ?>
			<div class="post-image">
				<a href="post/<?php echo e($post->slug); ?>.html"><video src="<?php echo e($post->files[0]->link); ?>" alt="" style="width: 100%"></video></a>
			</div>
		<?php else: ?>
			<div class="post-image">
				<?php if(count($post->files)>0): ?> 
					<?php $image = $post->files[0]->link; ?>
				<?php else: ?> 
					<?php $image = 'http://placehold.it/300x220'; ?>
				<?php endif; ?>
				<a href="post/<?php echo e($post->slug); ?>.html"><img src="<?php echo e($image); ?>" alt="" style="width: 300px;height: 220px;"></a>
			</div>
		<?php endif; ?>
		<?php if($post->post_type=='text'): ?>
			<div class="post-container">
				<a href="post/<?php echo e($post->slug); ?>.html"><h2 class="post-title"><?php echo e($post->title); ?></h2></a>
				<div class="post-content">
					<p><?php echo e($post->description); ?></p>
				</div>
			</div>
		<?php else: ?>
			<a href="post/<?php echo e($post->slug); ?>.html"><h2 class="post-title"><?php echo e($post->title); ?></h2></a>
		<?php endif; ?>

		<div class="post-meta">
			<span class="view"><a href=""><?php echo e($post->view); ?> views</a></span>
			<span class="author"><a href="author/<?php echo e($post->admin->name); ?>"><?php echo e($post->admin->name); ?></a></span>
			<span class="date"><a href="#"><?php echo e(date('G:i d-m-Y', strtotime($post->created_at))); ?></a></span>
		</div>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo $posts->render(); ?>

	<!-- End Category posts -->
</section>
<?php else: ?>
<section class="row">
	<h4 class="cat-title mb25">Chuyên Mục <?php echo e($key); ?></h4>
	<article class="post ten column">
		<h3>Không có bài viết nào được tìm thấy.</h3>
	</article>
</section>
<?php $__env->startSection('title'); ?>
| Không có bài viết
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('news.layout.single', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>