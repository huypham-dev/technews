<!doctype html>
<html lang="en">
<?php echo $__env->make('news.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<!-- Header -->
	<?php echo $__env->make('news.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- End Header -->

	<!-- Container -->
	<section class="container row clearfix">
		<!-- Menu top -->
		<?php echo $__env->make('news.partials.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- Inner Container -->
		<section class="inner-container clearfix">

			<!-- Content -->
			<section id="content" class="eight column row pull-left">
				<!-- Slider -->
				<?php echo $__env->make('news.partials.slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<!-- End Slider -->

				<?php echo $__env->yieldContent('content'); ?>
				
			</section>
			<!-- End Content -->

			<!-- Sidebar -->
			<?php echo $__env->make('news.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!-- End Sidebar -->

			<!-- Footer -->
			<?php echo $__env->make('news.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!-- End Footer -->

		</section>
		<!-- End Inner Container -->
	</section>
	<!-- End Container -->

	<!-- Import js -->
	<?php echo $__env->make('news.partials.importjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('js'); ?>
</body>
</html>