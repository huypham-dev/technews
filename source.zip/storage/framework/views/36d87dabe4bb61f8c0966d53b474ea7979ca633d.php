<?php $__env->startSection('content'); ?>
<!-- Posts -->
<?php if(isset($tag)): ?>
<?php $__env->startSection('title'); ?>
| Tag <?php echo e($tag->name); ?>

<?php $__env->stopSection(); ?>
<h4 class="cat-title mb25">Bài viết theo thẻ <?php echo e($tag->name); ?></h4>
<section class="row">
	<!-- Category posts -->
	<?php $__currentLoopData = $tag->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<article class="post six column">
		<div class="post-image">
			<?php if(count($post->files)>0): ?> 
				<?php $image = $post->files[0]->link; ?>
			<?php else: ?> 
				<?php $image = 'http://placehold.it/300x220'; ?>
			<?php endif; ?>
			<a href="post/<?php echo e($post->slug); ?>.html"><img src="<?php echo e($image); ?>" alt="" style="width: 300px;height: 220px;"></a>
		</div>

		<div class="post-container">
			<h2 class="post-title"><?php echo e($post->title); ?></h2>
			<div class="post-content">
				<p><?php echo e($post->description); ?></p>
			</div>
		</div>

		<div class="post-meta">
			<span class="author"><a href="author/<?php echo e($post->admin->name); ?>"><?php echo e($post->admin->name); ?></a></span>
			<span class="date"><a href="#"><?php echo e(date('G:i d-m-Y', strtotime($post->created_at))); ?></a></span>
		</div>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<section class="row">
	<h4 class="cat-title mb25">Bài viết theo thẻ <?php echo e($key); ?></h4>
	<article class="post ten column">
		<h3>Không có bài viết nào được tìm thấy.</h3>
	</article>
<?php $__env->startSection('title'); ?>
| Không tìm thấy
<?php $__env->stopSection(); ?>
<?php endif; ?>
	<!-- End Category posts -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('news.layout.single', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>