<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<!-- Latest compiled and minified CSS & JS -->
	  <base href="<?php echo e(asset('')); ?>"></base>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
</head>
<body>
	<div class="wrapper">
		<div class="container">
			<div class="form-signin">
				<form action="<?php echo e(route('login')); ?>" method="POST" role="form">
					<legend>Please login</legend>
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<?php if($errors->has('errlogin')): ?>
							<div class="alert alert-danger">
								<?php echo e($errors->first('errlogin')); ?>

							</div>
						<?php endif; ?>
						<label for="">Username</label>
						<input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>">
						<?php if( $errors->has('username') ): ?>
							<p class="text-warning"><?php echo e($errors->first('username')); ?></p>
						<?php endif; ?>
					</div>
					<div class="form-group">
						<label for="">Password</label>
						<input type="password" class="form-control" name="password">
						<?php if( $errors->has('password') ): ?>
							<p class="text-warning"><?php echo e($errors->first('password')); ?></p>
						<?php endif; ?>
					</div>
					<div class="checkbox">
                        <label>
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                    </div>
					<button class="btn btn-lg btn-primary btn-block" type="submit">Login</button> 
				</form>
			</div>
		</div>
	</div>
</body>
</html>