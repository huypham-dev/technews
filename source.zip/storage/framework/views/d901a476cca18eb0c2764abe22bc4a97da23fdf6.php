<?php $__env->startSection('content'); ?>
<?php if(isset($post)): ?>
<?php $__env->startSection('title'); ?>
| <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>
	<?php if($post->post_type == 'text'): ?>
	<a href="" class="featured-img">
		<?php if(count($post->files)>0): ?> 
			<?php $image = $post->files[0]->link; ?>
		<?php else: ?> 
			<?php $image = 'http://placehold.it/620x375'; ?>
		<?php endif; ?>
		<img src="<?php echo e($image); ?>" alt="">
	</a>
	<?php endif; ?>
	<!-- Youtube Video embed -->
	<?php if($post->post_type == 'video'): ?>
	<div class="flex-video widescreen">
		<video src="<?php echo e($post->files[0]->link); ?>" style="width: 100%" controls></video>
	</div>
	<?php endif; ?>
	<!-- End Youtube Video embed -->

	<h1 class="post-title"><?php echo e($post->title); ?></h1>

	 <?php echo $post->content; ?>


	<div class="post-meta">
		<span class="view"><a href=""><?php echo e($post->view); ?> views</a></span>
		<span class="author"><a href="#"><?php echo e($post->admin->name); ?></a></span>
		<span class="date"><a href=""><?php echo e(date('H:i d-m-Y', strtotime($post->created_at))); ?></a></span>
		<li class="widget widget_tag_cloud clearfix">
			<div class="tagcloud">
				<h3 style="float: left; margin: 0;margin-right: 10px; font-size: 18px; margin-top: 5px;">Tags:</h3>
				<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="tag/<?php echo e($tag->name); ?>" title="3 topics" style="font-size: 22pt;"><?php echo e($tag->name); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</li>
	</div>

	<div class="social-media clearfix">
		<ul>
			<li class="twitter">
				<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://localhost/post/<?php echo e($post->slug); ?>.html" data-text="">Tweet</a>
				<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
			</li>
			<li class="facebook">
				<script>(function(d, s, id) {
				  var js, fjs = d.getElementsByTagName(s)[0];
				  if (d.getElementById(id)) return;
				  js = d.createElement(s); js.id = id;
				  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
				  fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));
				</script>
				<div class="fb-like" data-href="http://www.nextwpthemes.com/" data-send="false" data-layout="button_count" data-width="450" data-show-faces="true"></div>
			</li>
			<li class="google_plus">
				<div class="g-plusone" data-size="medium"></div>
				<script type="text/javascript">
				  (function() {
					var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
					po.src = 'https://apis.google.com/js/plusone.js';
					var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
				  })();
				</script>
			</li>
		</ul>
	</div>

	<div class="clear"></div>

	<div class="line"></div>

	<h4 class="post-title">Bình Luận</h4>
	<script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.10&appId=863868720428280";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
    <div class="fb-comments" data-href="http://localhost/post/<?php echo e($post->title); ?>" data-numposts="5" data-width="100%"></div>
	<br>
	<h4 class="post-title">Tin Khác</h4>
	<ul class="arrow-list">
		<?php $__currentLoopData = $lq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="post/<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
<?php else: ?>
<section class="row">
	<article class="post ten column">
		<h3>Bài viết không tồn tại.</h3>
	</article>
</section>
<?php $__env->startSection('title'); ?>
| Không tìm thấy
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('news/layout/single', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>