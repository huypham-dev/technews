<div class="flexslider mb25">
	<ul class="slides no-bullet inline-list m0">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
     		<a href="post/<?php echo e($post->slug); ?>.html">
                <img alt="<?php echo e($post->feture); ?>" src="<?php echo e($post->feture); ?>"> 
            </a>                    
     		<div class="flex-caption">
                <div class="desc">
                	<h1><a href="post/<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a></h1>
                	<p><?php echo e($post->description); ?></p>
                </div>
            </div>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>