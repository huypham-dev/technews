<!-- Menu -->
<header class="clearfix">
	<nav id="main-menu" class="left navigation">
		<ul class="sf-menu no-bullet inline-list m0">
			<li><a href="">Trang Chủ</a></li>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<a href="category/<?php echo e($cate->slug); ?>"><?php echo e($cate->name); ?></a>
	    		</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<li><a href="contact.html">Liên Hệ</a></li>
		</ul>
	</nav>

	<div class="search-bar right clearfix">
		<form action="<?php echo e(route('search')); ?>" method="get">
			<input name="key" type="text" data-value="search" value="search">
			<input type="submit" value="">
		</form>
	</div>
</header>
