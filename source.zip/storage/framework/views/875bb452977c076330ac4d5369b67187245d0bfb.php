<!DOCTYPE html>
<html>
<head>
	<title>Abc</title>
</head>
<body>
	<h1>Hello word</h1>
	<?php echo e($id); ?>

	<form method="post" action="<?php echo e(route('post')); ?>">
		<?php echo e(csrf_field()); ?>

		<input type="text" name="username">
		<input type="submit" name="submit" value="Sent">
	</form>
</body>
</html>