<?php $__env->startSection('content'); ?>
<!-- Content -->
<section id="content" class="ten column row pull-left">
	<div class="page-container error-404">
		<p>error <b>404</b><span>Xin lỗi, Trang này có thể bị xóa hoặc không tồn tại.</span></p>
	</div>
</section>
<!-- Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('news.layout.single', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>