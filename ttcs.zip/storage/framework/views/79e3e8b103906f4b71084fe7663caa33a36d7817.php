<?php $__env->startSection('title'); ?>
| Tìm kiếm bài viết
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Posts -->
<h4 class="cat-title mb25">Từ Khóa <?php echo e($key); ?></h4>
<section class="row">
	<?php if(count($posts)==0): ?>
	<article class="post ten column">
		<h3>Không có bài viết nào được tìm thấy.</h3>
	</article>
	<?php endif; ?>
	<!-- Category posts -->
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<article class="post six column">
		<div class="post-image zoom-out">
			<?php if($post->feture): ?> 
				<?php $image = $post->feture; ?>
			<?php else: ?> 
				<?php $image = 'http://placehold.it/300x220'; ?>
			<?php endif; ?>
			<figure><a href="post/<?php echo e($post->slug); ?>.html"><img src="<?php echo e($image); ?>" alt="" style="width: 300px;height: 220px;"></a></figure>
		</div>

		<div class="post-container">
			<a href="post/<?php echo e($post->slug); ?>.html"><h2 class="post-title"><?php echo e($post->title); ?></h2></a>
			<div class="post-content">
				<p><?php echo e($post->description); ?></p>
			</div>
		</div>

		<div class="post-meta">
			<span class="view"><a href=""><?php echo e($post->view); ?> views</a></span>
			<span class="author"><a href="author/<?php echo e($post->admin->name); ?>"><?php echo e($post->admin->name); ?></a></span>
			<span class="date"><a href="#"><?php echo e(date('G:i d-m-Y', strtotime($post->created_at))); ?></a></span>
		</div>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<!-- End Category posts -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('news.layout.single', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>