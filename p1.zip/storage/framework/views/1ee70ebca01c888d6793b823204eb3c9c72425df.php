<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
	    <div class="container-fluid">
	        <div class="row">
	            <div class="col-lg-12">
	            	<div class="data" id="data">
	            		ok
	            	</div>
	            </div>
	        </div>
	    </div>
	</div>
	<?php echo e(csrf_field()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#data').click(function(event) {
				$.ajax({
				url: 'admin/category/list',
				type: 'get',
				dataType: 'html',
				//data: {_token: $('input[name=_token]').val()},
				})
				.done(function(data) {
					console.log(data);
				})
				.fail(function() {
					console.log("error");
				})
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>