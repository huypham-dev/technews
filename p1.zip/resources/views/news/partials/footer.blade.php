<footer class="row clearfix">
	<!-- Footer widgets -->
	<ul class="no-bullet clearfix">
		<li class="widget four column">
			<h3 class="widget-title">Thông Tin</h3>
        	<div class="textwidget">
        		<img alt="" src="images/logo/logo.png">
        		<p>BTL Trang Tin Tức Công Nghệ.</p>
        		<p>GV Hướng Dẫn Lê Đức Thuận.</p>
       		</div>
		</li>
		<li class="widget four column">
			<h3 class="widget-title">Danh Mục Chính</h3>
			<div class="twitter-widget">
        		<ul class="arrow-list">
        			<li><a href="category/cong-nghe">Tin Công Nghệ</a></li>
        			<li><a href="category/thu-thuat">Thủ Thuật</a></li>
        			<li><a href="category/su-kien">Sự Kiện</a></li>
        		</ul>
        	</div>
		</li>
		<li class="widget four column">
			<h3 class="widget-title">Liên Hệ</h3>
        	<div class="twitter-widget">
        		<ul class="arrow-list">
        			<li><a href="#">Phạm Đức Tính</a></li>
        			<li><a href="#">Ngô Quang Minh</a></li>	
        			<li><a href="#">Phạm Trung Kiên</a></li>
        		</ul>
        	</div>
		</li>
	</ul>
	<!-- End Footer widgets -->

	<div class="copyright clearfix">
		© Copyright 2017 HVKT Mật Mã
	</div>

	<div id="back-to-top" class="right">
		<a href="#top">Back to Top</a>
	</div>
</footer>